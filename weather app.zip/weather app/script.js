// Weather fetching function with REAL API only
async function getWeather(city) {
    console.log(`Getting weather for: ${city}`);
    
    showLoading(true);
    hideError();
    document.getElementById('weatherInfo').style.display = 'none';
    
    try {
        const apiKey = 'c62bca153fce795a2ca86684c9de2e41'; //api key
        
        let url;
        
        // SPECIAL FIX FOR MIRI - Use coordinates directly
        if (city.toLowerCase() === 'miri') {
            // Miri's exact coordinates (latitude: 4.3993, longitude: 113.9914)
            url = `https://api.openweathermap.org/data/2.5/weather?lat=4.3993&lon=113.9914&units=metric&appid=${apiKey}`;
            console.log('Using Miri coordinates fix');
        } else {
            // For other cities, use normal search with Malaysia country code
            url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;
        }
        
        console.log('Fetching from:', url);
        
        const response = await fetch(url);
        
        console.log('Response status:', response.status);
        
        if (response.status === 401) {
            throw new Error('Invalid API key. Please check your key.');
        }
        if (response.status === 404) {
            throw new Error(`City "${city}" not found. Please check the spelling.`);
        }
        if (!response.ok) {
            throw new Error(`Error ${response.status}: Unable to fetch weather`);
        }
        
        const data = await response.json();
        console.log('Weather data:', data);
        
        // Manually set the city name to "Miri" if coordinates returned a different name
        if (city.toLowerCase() === 'miri') {
            data.name = 'Miri'; // Override the returned name
        }
        
        displayWeatherData(data);
        
    } catch (error) {
        showError(error.message);
        console.error('Error details:', error);
    } finally {
        showLoading(false);
    }
}

function displayWeatherData(data) {
    document.getElementById('cityName').textContent = data.name;
    document.getElementById('temperature').textContent = `${Math.round(data.main.temp)}°C`;
    document.getElementById('condition').textContent = data.weather[0].description;
    document.getElementById('humidity').textContent = `${data.main.humidity}%`;
    document.getElementById('wind').textContent = `${data.wind.speed} km/h`;
    document.getElementById('pressure').textContent = `${data.main.pressure} hPa`;
    
    const icon = getWeatherIcon(data.weather[0].main);
    document.getElementById('weatherIcon').textContent = icon;
    
    document.getElementById('weatherInfo').style.display = 'block';
}

function getWeatherIcon(condition) {
    const icons = {
        'Clear': '☀️',
        'Clouds': '☁️',
        'Rain': '🌧️',
        'Drizzle': '🌦️',
        'Thunderstorm': '⛈️',
        'Snow': '❄️',
        'Mist': '🌫️',
        'Smoke': '💨',
        'Haze': '🌫️',
        'Fog': '🌫️'
    };
    return icons[condition] || '🌡️';
}

function showLoading(show) {
    document.getElementById('loading').style.display = show ? 'block' : 'none';
}

function showError(message) {
    const errorDiv = document.getElementById('errorMessage');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    setTimeout(() => {
        errorDiv.style.display = 'none';
    }, 4000);
}

function hideError() {
    document.getElementById('errorMessage').style.display = 'none';
}

// Event listeners
document.getElementById('searchBtn').addEventListener('click', () => {
    const city = document.getElementById('cityInput').value.trim();
    if (city) {
        getWeather(city);
    }
});

document.getElementById('cityInput').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        document.getElementById('searchBtn').click();
    }
});

// Load default city on page load - NOW SHOWS MIRI!
getWeather('Miri');