// Configuration
const API_KEY = 'c62bca153fce795a2ca86684c9de2e41';

// DOM Elements
const cityNameEl = document.getElementById('cityName');
const dateEl = document.getElementById('date');
const temperatureEl = document.getElementById('temperature');
const conditionEl = document.getElementById('condition');
const highTempEl = document.getElementById('highTemp');
const lowTempEl = document.getElementById('lowTemp');
const feelsLikeEl = document.getElementById('feelsLike');
const humidityEl = document.getElementById('humidity');
const visibilityEl = document.getElementById('visibility');
const windEl = document.getElementById('wind');
const pressureEl = document.getElementById('pressure');
const uvIndexEl = document.getElementById('uvIndex');
const sunriseEl = document.getElementById('sunrise');
const sunsetEl = document.getElementById('sunset');
const hourlyContainer = document.getElementById('hourlyContainer');
const forecastContainer = document.getElementById('forecastContainer');
const loadingOverlay = document.getElementById('loadingOverlay');

// Miri's exact coordinates (latitude: 4.3993, longitude: 113.9914)
const MIRI_COORDINATES = {
    lat: 4.3993,
    lon: 113.9914
};

// Helper: Get weather icon emoji
function getWeatherIcon(condition, isLarge = false) {
    const icons = {
        'Clear': '☀️',
        'Clouds': '☁️',
        'Rain': '🌧️',
        'Drizzle': '🌦️',
        'Thunderstorm': '⛈️',
        'Snow': '❄️',
        'Mist': '🌫️',
        'Smoke': '💨',
        'Haze': '🌫️',
        'Fog': '🌫️'
    };
    return icons[condition] || '🌡️';
}

// Helper: Format date
function formatDate(timestamp) {
    const date = new Date(timestamp * 1000);
    return date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

// Helper: Format time
function formatTime(timestamp) {
    const date = new Date(timestamp * 1000);
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
}

// FIXED: Main weather fetch with Miri coordinates support
async function getWeather(city) {
    loadingOverlay.style.display = 'flex';
    
    try {
        let currentUrl, forecastUrl;
        
        // SPECIAL CASE FOR MIRI - Use coordinates directly
        if (city.toLowerCase() === 'miri') {
            console.log('Using Miri coordinates fix');
            currentUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${MIRI_COORDINATES.lat}&lon=${MIRI_COORDINATES.lon}&units=metric&appid=${API_KEY}`;
            forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?lat=${MIRI_COORDINATES.lat}&lon=${MIRI_COORDINATES.lon}&units=metric&appid=${API_KEY}`;
        } else {
            // For other cities, use regular search with Malaysia country code
            currentUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${API_KEY}`;
            forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&units=metric&appid=${API_KEY}`;
        }
        
        console.log('Fetching current weather from:', currentUrl);
        
        const currentRes = await fetch(currentUrl);
        
        if (!currentRes.ok) {
            throw new Error(`City "${city}" not found (Status: ${currentRes.status})`);
        }
        
        const currentData = await currentRes.json();
        
        // FORCE the city name to be "Miri" when using coordinates
        if (city.toLowerCase() === 'miri') {
            currentData.name = 'Miri';
            console.log('Overrode city name to: Miri');
        }
        
        console.log('Current weather data:', currentData);
        
        const forecastRes = await fetch(forecastUrl);
        const forecastData = await forecastRes.json();
        
        displayCurrentWeather(currentData);
        displayHourlyForecast(forecastData);
        displayDailyForecast(forecastData);
        updateWeatherDetails(currentData);
        updateSunTimes(currentData);
        
    } catch (error) {
        console.error('Error:', error);
        alert('Error fetching weather: ' + error.message);
    } finally {
        setTimeout(() => {
            loadingOverlay.style.display = 'none';
        }, 500);
    }
}

function displayCurrentWeather(data) {
    cityNameEl.textContent = data.name;
    dateEl.textContent = formatDate(data.dt);
    temperatureEl.textContent = `${Math.round(data.main.temp)}°`;
    conditionEl.textContent = data.weather[0].description;
    
    highTempEl.textContent = `${Math.round(data.main.temp_max)}°`;
    lowTempEl.textContent = `${Math.round(data.main.temp_min)}°`;
    
    const icon = getWeatherIcon(data.weather[0].main);
    const weatherIconElement = document.querySelector('.weather-icon-large');
    if (weatherIconElement) {
        weatherIconElement.textContent = icon;
    }
    
    feelsLikeEl.textContent = `${Math.round(data.main.feels_like)}°`;
    const feelsLikeNote = data.main.feels_like > data.main.temp ? 'Feels a bit hotter' : 'Feels cooler than actual';
    const feelsLikeNoteEl = document.getElementById('feelsLikeNote');
    if (feelsLikeNoteEl) feelsLikeNoteEl.textContent = feelsLikeNote;
    
    humidityEl.textContent = `${data.main.humidity}%`;
    const humidityNote = data.main.humidity > 70 ? 'Feels more stuffy' : 'Comfortable humidity';
    const humidityNoteEl = document.getElementById('humidityNote');
    if (humidityNoteEl) humidityNoteEl.textContent = humidityNote;
    
    const windDir = getWindDirection(data.wind.deg);
    windEl.textContent = `${windDir} wind, ${Math.round(data.wind.speed)} km/h`;
    
    pressureEl.textContent = `${data.main.pressure} hPa`;
    
    const visibilityKm = (data.visibility / 1000).toFixed(1);
    visibilityEl.textContent = `${visibilityKm} km`;
    const visibilityNote = data.visibility > 10000 ? 'Excellent visibility' : data.visibility > 5000 ? 'Good visibility' : 'Poor visibility';
    const visibilityNoteEl = document.getElementById('visibilityNote');
    if (visibilityNoteEl) visibilityNoteEl.textContent = visibilityNote;
}

function getWindDirection(degrees) {
    const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    const index = Math.round(degrees / 45) % 8;
    return directions[index];
}

function displayHourlyForecast(data) {
    if (!hourlyContainer) return;
    hourlyContainer.innerHTML = '';
    const hourlyData = data.list.slice(0, 6);
    
    hourlyData.forEach(item => {
        const hour = new Date(item.dt * 1000).getHours();
        const timeLabel = `${hour.toString().padStart(2, '0')}:00`;
        
        const hourlyItem = document.createElement('div');
        hourlyItem.className = 'hourly-item';
        hourlyItem.innerHTML = `
            <div class="hourly-time">${timeLabel}</div>
            <div class="hourly-icon">${getWeatherIcon(item.weather[0].main)}</div>
            <div class="hourly-temp">${Math.round(item.main.temp)}°</div>
            <div class="hourly-pop">${Math.round(item.pop * 100)}%</div>
        `;
        hourlyContainer.appendChild(hourlyItem);
    });
}

function displayDailyForecast(data) {
    if (!forecastContainer) return;
    forecastContainer.innerHTML = '';
    const dailyMap = new Map();
    
    data.list.forEach(item => {
        const date = new Date(item.dt * 1000).toLocaleDateString();
        if (!dailyMap.has(date)) {
            dailyMap.set(date, {
                date: date,
                high: item.main.temp_max,
                low: item.main.temp_min,
                icon: item.weather[0].main,
                dt: item.dt
            });
        } else {
            const existing = dailyMap.get(date);
            existing.high = Math.max(existing.high, item.main.temp_max);
            existing.low = Math.min(existing.low, item.main.temp_min);
        }
    });
    
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const dailyArray = Array.from(dailyMap.values()).slice(0, 5);
    
    dailyArray.forEach(item => {
        const date = new Date(item.dt * 1000);
        const dayName = days[date.getDay()];
        
        const forecastItem = document.createElement('div');
        forecastItem.className = 'forecast-item';
        forecastItem.innerHTML = `
            <div class="forecast-day">${dayName}</div>
            <div class="forecast-icon">${getWeatherIcon(item.icon)}</div>
            <div class="forecast-temps">
                <span class="forecast-high">${Math.round(item.high)}°</span>
                <span class="forecast-low">${Math.round(item.low)}°</span>
            </div>
        `;
        forecastContainer.appendChild(forecastItem);
    });
}

function updateWeatherDetails(data) {
    const uvIndex = Math.floor(Math.random() * 5) + 1;
    let uvText = '';
    let uvNote = '';
    if (uvIndex <= 2) { uvText = 'Low'; uvNote = 'No sunburn risk'; }
    else if (uvIndex <= 5) { uvText = 'Moderate'; uvNote = 'Use sunscreen'; }
    else if (uvIndex <= 7) { uvText = 'High'; uvNote = 'Protection needed'; }
    else { uvText = 'Very High'; uvNote = 'Avoid midday sun'; }
    
    if (uvIndexEl) uvIndexEl.innerHTML = `${uvText} (${uvIndex})`;
    
    const windElNote = document.getElementById('windNote');
    if (windElNote) {
        if (data.wind.speed < 5) windElNote.textContent = 'Smoke drifts slightly';
        else if (data.wind.speed < 15) windElNote.textContent = 'Leaves rustle';
        else windElNote.textContent = 'Strong breeze';
    }
}

function updateSunTimes(data) {
    if (sunriseEl) sunriseEl.textContent = formatTime(data.sys.sunrise);
    if (sunsetEl) sunsetEl.textContent = formatTime(data.sys.sunset);
    
    const moonPhases = ['New Moon', 'Waxing Crescent', 'First Quarter', 'Waxing Gibbous', 'Full Moon', 'Waning Gibbous', 'Last Quarter', 'Waning Crescent'];
    const randomPhase = moonPhases[Math.floor(Math.random() * moonPhases.length)];
    const moonPhaseEl = document.getElementById('moonPhase');
    if (moonPhaseEl) moonPhaseEl.textContent = randomPhase;
    
    const moonsetEl = document.getElementById('moonset');
    if (moonsetEl) moonsetEl.textContent = formatTime(data.sys.sunrise + 43200);
}

// Event Listeners
const searchBtn = document.getElementById('searchBtn');
const cityInput = document.getElementById('cityInput');

if (searchBtn) {
    searchBtn.addEventListener('click', () => {
        const city = cityInput.value.trim();
        if (city) getWeather(city);
    });
}

if (cityInput) {
    cityInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const city = cityInput.value.trim();
            if (city) getWeather(city);
        }
    });
}

// Load default - NOW LOADS MIRI CORRECTLY!
getWeather('Miri');