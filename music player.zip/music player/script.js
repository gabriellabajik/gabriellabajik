const audio = new Audio();
const playBtn = document.getElementById('play');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const progress = document.getElementById('progress');
const progressContainer = document.getElementById('progress-container');
const title = document.getElementById('title');
const artist = document.getElementById('artist');
const cover = document.getElementById('cover');

const songs = [
    {
        name: 'Misery',
        artist: 'Gloomhush',
        cover: 'download.jpg',
        url: 'misery.mp3'
    },
    {
        name: 'Kicau',
        artist: 'Kicau',
        cover: 'scubaCat.gif',
        url: 'kicau-maniaa.mp3'
    }
];

let songIndex = 0;
let isPlaying = false;

function loadSong(song) {
    title.innerText = song.name;
    artist.innerText = song.artist;
    cover.src = song.cover;
    audio.src = song.url;
}

function playSong() {
    isPlaying = true;
    playBtn.innerText = '⏸';
    audio.play().catch(error => {
        console.error("Autoplay blocked or error:", error);
        isPlaying = false;
        playBtn.innerText = '▶';
    });
}

function pauseSong() {
    isPlaying = false;
    playBtn.innerText = '▶';
    audio.pause();
}

playBtn.addEventListener('click', () => {
    isPlaying ? pauseSong() : playSong();
});

prevBtn.addEventListener('click', () => {
    songIndex = (songIndex - 1 + songs.length) % songs.length;
    loadSong(songs[songIndex]);
    playSong();
});

nextBtn.addEventListener('click', () => {
    songIndex = (songIndex + 1) % songs.length;
    loadSong(songs[songIndex]);
    playSong();
});

audio.addEventListener('timeupdate', (e) => {
    const { duration, currentTime } = e.srcElement;
    if (isNaN(duration)) return;
    const progressPercent = (currentTime / duration) * 100;
    progress.style.width = `${progressPercent}%`;
});

progressContainer.addEventListener('click', (e) => {
    const width = progressContainer.clientWidth;
    const clickX = e.offsetX;
    const duration = audio.duration;
    audio.currentTime = (clickX / width) * duration;
});

audio.addEventListener('ended', () => {
    nextBtn.click();
});

loadSong(songs[songIndex]);
